package com.example.eva2appmoviliot
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.spashactivitie)

        // Esperar 3 segundos y luego ir al Login
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()  // Cerrar Splash para que no pueda volver atrás
        }, 3000) // 3000 milisegundos = 3 segundos
    }
}
