package com.example.eva2appmoviliot

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class RecoverPasswordActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Set up the layout for this activity
        // setContentView(R.layout.activity_recover_password)
    }
}
